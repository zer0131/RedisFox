package main

import (
	_ "fweb/routers"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}

